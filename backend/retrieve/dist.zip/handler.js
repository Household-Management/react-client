"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
function retrieve(event, context, callback) {
    const dynamodb = new aws_sdk_1.DynamoDB();
    let tableName;
    switch (event.metadata.stage) {
        case "staging":
            tableName = "Homeplanit-Users-Staging";
            break;
    }
    if (!tableName) {
        return callback({
            message: "No table name defined for specified stage",
            statusCode: 500,
        });
    }
    const params = {
        Key: {
            username: {
                S: event.user,
            },
        },
        TableName: tableName
    };
    console.info("Checking if database user exists.");
    dynamodb.getItem(params, (getError, data) => {
        callback(getError, getError ? null : aws_sdk_1.DynamoDB.Converter.unmarshall(data.Item));
    });
}
exports.retrieve = retrieve;
